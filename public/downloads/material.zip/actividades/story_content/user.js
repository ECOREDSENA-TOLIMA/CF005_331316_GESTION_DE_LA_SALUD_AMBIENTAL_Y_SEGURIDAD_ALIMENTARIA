function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ataQnlZo1i":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

