function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6rda5n9wBfK":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

